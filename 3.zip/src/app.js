import Web3 from 'web3';
<script src="https://cdnjs.cloudflare.com/ajax/libs/web3/1.6.0/web3.min.js"></script>


const web3 = new Web3('YOUR_PROVIDER_URL'); // استبدل YOUR_PROVIDER_URL بعنوان مزوِّد Ethereum الخاص بك
// تكوين واستخدام Web3.js

    const contractABI = [
        [
            {
                "anonymous": false,
                "inputs": [
                    {
                        "indexed": true,
                        "internalType": "address",
                        "name": "owner",
                        "type": "address"
                    },
                    {
                        "indexed": true,
                        "internalType": "address",
                        "name": "spender",
                        "type": "address"
                    },
                    {
                        "indexed": false,
                        "internalType": "uint256",
                        "name": "value",
                        "type": "uint256"
                    }
                ],
                "name": "Approval",
                "type": "event"
            },
            {
                "anonymous": false,
                "inputs": [
                    {
                        "indexed": true,
                        "internalType": "address",
                        "name": "from",
                        "type": "address"
                    },
                    {
                        "indexed": true,
                        "internalType": "address",
                        "name": "to",
                        "type": "address"
                    },
                    {
                        "indexed": false,
                        "internalType": "uint256",
                        "name": "value",
                        "type": "uint256"
                    }
                ],
                "name": "Transfer",
                "type": "event"
            },
            {
                "inputs": [
                    {
                        "internalType": "address",
                        "name": "owner",
                        "type": "address"
                    },
                    {
                        "internalType": "address",
                        "name": "spender",
                        "type": "address"
                    }
                ],
                "name": "allowance",
                "outputs": [
                    {
                        "internalType": "uint256",
                        "name": "",
                        "type": "uint256"
                    }
                ],
                "stateMutability": "view",
                "type": "function"
            },
            {
                "inputs": [
                    {
                        "internalType": "address",
                        "name": "spender",
                        "type": "address"
                    },
                    {
                        "internalType": "uint256",
                        "name": "value",
                        "type": "uint256"
                    }
                ],
                "name": "approve",
                "outputs": [
                    {
                        "internalType": "bool",
                        "name": "",
                        "type": "bool"
                    }
                ],
                "stateMutability": "nonpayable",
                "type": "function"
            },
            {
                "inputs": [
                    {
                        "internalType": "address",
                        "name": "account",
                        "type": "address"
                    }
                ],
                "name": "balanceOf",
                "outputs": [
                    {
                        "internalType": "uint256",
                        "name": "",
                        "type": "uint256"
                    }
                ],
                "stateMutability": "view",
                "type": "function"
            },
            {
                "inputs": [],
                "name": "totalSupply",
                "outputs": [
                    {
                        "internalType": "uint256",
                        "name": "",
                        "type": "uint256"
                    }
                ],
                "stateMutability": "view",
                "type": "function"
            },
            {
                "inputs": [
                    {
                        "internalType": "address",
                        "name": "to",
                        "type": "address"
                    },
                    {
                        "internalType": "uint256",
                        "name": "value",
                        "type": "uint256"
                    }
                ],
                "name": "transfer",
                "outputs": [
                    {
                        "internalType": "bool",
                        "name": "",
                        "type": "bool"
                    }
                ],
                "stateMutability": "nonpayable",
                "type": "function"
            },
            {
                "inputs": [
                    {
                        "internalType": "address",
                        "name": "from",
                        "type": "address"
                    },
                    {
                        "internalType": "address",
                        "name": "to",
                        "type": "address"
                    },
                    {
                        "internalType": "uint256",
                        "name": "value",
                        "type": "uint256"
                    }
                ],
                "name": "transferFrom",
                "outputs": [
                    {
                        "internalType": "bool",
                        "name": "",
                        "type": "bool"
                    }
                ],
                "stateMutability": "nonpayable",
                "type": "function"
            }
        ]
    ];

    const contractAddress = '0xe775d1642D6BEC72f6B03c1b353039bc76527193'; // Replace with your contract address

    // Create a contract instance
    const contract = new web3.eth.Contract(contractABI, contractAddress);

    // Define the user's Ethereum wallet address
    const userAddress = '0xe775d1642D6BEC72f6B03c1b353039bc76527193'; // Replace with your wallet address

    // Swap function parameters
    const tokenIn = '0x2170Ed0880ac9A755fd29B2688956BD959F933F8'; // Replace with the token in address
    const amountIn = 100; // Example amount
    const tokenOut = '0x2170Ed0880ac9A755fd29B2688956BD959F933F8'; // Replace with the token out address

    // Function to initiate a swap
    async function swapTokens() {
        try {
            // Call the swap function in the contract
            const result = await contract.methods.swap(tokenIn, amountIn, tokenOut).send({ from: userAddress });

            console.log('Swap successful. Transaction hash:', result.transactionHash);
        } catch (error) {
            console.error('Swap failed. Error:', error);
        }
    }

    // Connect to the user's wallet (e.g., MetaMask)
    async function connectWallet() {
        try {
            await ethereum.request({ method: 'eth_requestAccounts' });
            console.log('Connected to wallet.');
            swapTokens(); // Call swapTokens after connecting to the wallet
        } catch (error) {
            console.error('Wallet connection failed. Error:', error);
        }
    }

    // Call connectWallet to initiate the process
    connectWallet();

